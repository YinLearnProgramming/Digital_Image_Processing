function [r,c] = i_spy ( object_im, big_im, x )

% note that this implementation does not use variable "x"

Ro = size(object_im, 1); 
Co = size(object_im, 2); 

Rb = size(big_im, 1); 
Cb = size(big_im, 2); 


o_im = int16(object_im);
b_im = int16(big_im);


for r = 1 : Rb - (Ro-1)
    for c = 1 : Cb - (Co-1)
        diff_val = b_im(r:r+(Ro-1), c:c+(Co-1), : ) - o_im; 
        if ( sum ( abs ( diff_val(:)) ) == 0 )
            return;
        end
    end
end
