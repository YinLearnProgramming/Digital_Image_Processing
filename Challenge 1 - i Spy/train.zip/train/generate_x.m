function [x] = generate_x ( b_im )

% nothing useful for now
x.table = [1 2 3];
x.magic = [25.5 2.1];